import { LiaOutdentSolid } from "react-icons/lia";

export const API_URL = "https://finalpw.harifly.in/api";
export const API= {
    homesliders: `${API_URL}/home-sliders`,
    courses: `${API_URL}/courses`,
    categories: `${API_URL}/categories`,
    sub_categories: `${API_URL}/sub-categories`,
    trusted_sections: `${API_URL}/trusted-sections`,
    home_vidyapeeth_centers: `${API_URL}/home-offline-vidyapeeth-centers`,
    results_n_app_store: `${API_URL}/results-n-app-store`,
    study_materials: `${API_URL}/study-materials`,
    testimonials: `${API_URL}/testimonials`,
    header_footer: `${API_URL}/header-footer`,
    about_us: `${API_URL}/about-us`,
    privacy_policy: `${API_URL}/privacy-policy`,
    logout_student: `${API_URL}/logout-student`,
    student_profile: `${API_URL}/student-profile`,
    

}

